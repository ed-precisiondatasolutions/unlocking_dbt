--These are literal expressions
{{ "This compiles to a string" }}
{{ 100 }}
{{ ['this', 'is', 'a', 'list', 'of', 'objects'] }}

--These are math expressions
{{ 19 + 23 }}
{{ 79 - 37 }}
{{ 7 * 6 }}

--These are comparison expressions
{{ 1 == 1 }}
{{ 1 != 1 }}
{{ 1 < 2 }}
{{ 1 > 2 }}